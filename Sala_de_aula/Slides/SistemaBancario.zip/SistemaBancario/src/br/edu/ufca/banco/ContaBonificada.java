package br.edu.ufca.banco;

public class ContaBonificada extends Conta{
	
	private double bonus;
	private double txBonus = 0.01;
	
	public ContaBonificada(String n, double s, Cliente c) {
		super(n, s, c);
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public double getTxBonus() {
		return txBonus;
	}

	public void setTxBonus(double txBonus) {
		this.txBonus = txBonus;
	}
	
	@Override
	public void creditar(double valor) {
		this.bonus += valor*this.txBonus;
		super.creditar(valor);
	}
	
	public void renderBonus() {
		super.creditar(this.bonus);
		this.bonus = 0;
	}

}
