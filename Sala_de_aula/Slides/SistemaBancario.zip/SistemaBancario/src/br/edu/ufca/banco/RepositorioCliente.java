package br.edu.ufca.banco;

import java.util.ArrayList;

public class RepositorioCliente {
	
	private ArrayList<Cliente> clientes;
	
	public RepositorioCliente() {
		this.clientes = new ArrayList<Cliente>();
	}

	public ArrayList<Cliente> getClientes() {
		return clientes;
	}
	

	public void setClientes(ArrayList<Cliente> clientes) {
		this.clientes = clientes;
	}
	
	

}
