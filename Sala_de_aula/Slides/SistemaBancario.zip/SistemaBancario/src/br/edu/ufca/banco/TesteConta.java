package br.edu.ufca.banco;

import java.util.ArrayList;

public class TesteConta {
	
	public static void main(String[] args) {
		/*Cliente cliente = new Cliente("Joao", "1234");
		System.out.println(cliente.toString());
		Poupanca p = new Poupanca("1", 0, cliente, 0.01);
		Conta conta = p;
		
		p.renderJuros();
		if(conta instanceof Poupanca) {
			((Poupanca)conta).renderJuros();
		}else {
			System.out.println("Poupan�a inexistente");
		}
		
		conta.creditar(100);
		conta = new ContaBonificada("2", 45, cliente);
		conta.creditar(100);*/
		ArrayList<Integer> inteiros = new ArrayList<Integer>();
		for(int i = 1; i < 5; i++) {
			inteiros.add(i);
		}
		//System.out.println(inteiros.contains(4));
		//System.out.println(inteiros.contains(5));
		
		RepositorioCliente clientes = new RepositorioCliente();
		clientes.getClientes().add(new Cliente("Maria", "1234"));
		Cliente c = new Cliente("Maria", "1234");
		System.out.println(clientes.getClientes().contains(c));
		
	}

}
