package br.edu.ufca.banco;

public class ContaImposto extends ContaAbstrata{
	
	private double taxaImposto;
	
	public ContaImposto(String num, double sal, Cliente c)
	{
		super(num, sal, c);
		this.taxaImposto = 0.02;
	}
	
	@Override
	public void debitar(double valor) {		
		double valorFinal = valor + valor*taxaImposto;
		if(valorFinal <= this.saldo) {
			this.saldo -= valorFinal;
			System.out.println("Saque realizado.");
		}else {
			System.out.println("Saque n�o realizado "
					+ "(saldo insuficiente).");
		}	
	}

	public double getTaxaImposto() {
		return taxaImposto;
	}

	public void setTaxaImposto(double taxaImposto) {
		this.taxaImposto = taxaImposto;
	}

}
