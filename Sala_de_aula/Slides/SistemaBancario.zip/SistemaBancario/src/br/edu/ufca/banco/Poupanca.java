package br.edu.ufca.banco;

public class Poupanca extends Conta{
	
	private double juros;
	
	public Poupanca(String n, double v, Cliente c, double j) {
		super(n,v,c);
		this.juros = j;
	}

	public double getJuros() {
		return juros;
	}

	public void setJuros(double juros) {
		this.juros = juros;
	}
	
	public void renderJuros() {
		double credito = this.getSaldo()*this.juros;
		this.creditar(credito);
	}
	
}
