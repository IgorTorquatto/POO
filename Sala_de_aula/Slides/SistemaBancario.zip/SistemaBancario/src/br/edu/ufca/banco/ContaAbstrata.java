package br.edu.ufca.banco;

public abstract class ContaAbstrata {
	
	private String numero;
	protected double saldo;
	private Cliente cliente;
	
	public ContaAbstrata(String num, double sal, Cliente c){
		this.numero = num;
		this.saldo = sal;
		this.cliente = c;
	}
	
	public abstract void debitar(double valor);
	
	public void creditar(double valor) {
		saldo = saldo + valor;
	}
	
	public void transferir(ContaAbstrata c, double valor) {
		
		this.debitar(valor);
		c.creditar(valor);
	
	}
	public double consultarSaldo() {
		return saldo;
	}
	
	@Override
	public String toString() {
		String resultado = "Conta n� " + numero + 
				"\nSaldo R$" + saldo + 
				"\nCliente: " +this.cliente.getNome();
		return resultado;
	}
	
	@Override
	public boolean equals(Object c) {
		if(this.numero.equals(((ContaAbstrata)c).numero)) {
			return true;
		}else {
			return false;
		}
	}
	
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public double getSaldo() {
		return saldo;
	}

}
