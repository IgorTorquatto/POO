package br.edu.ufca.banco;

public class Conta extends ContaAbstrata{

	public Conta(String num, double sal, Cliente c){
		super(num, sal, c);
	}
	
	@Override
	public void debitar(double valor) {
		double saldo = this.getSaldo();
		if(valor <= saldo) {
			saldo -= valor;
			System.out.println("Saque realizado");
		}else {
			System.out.println("Saque n�o realizado "
					+ "(saldo insuficiente).");
		}
	}





}
