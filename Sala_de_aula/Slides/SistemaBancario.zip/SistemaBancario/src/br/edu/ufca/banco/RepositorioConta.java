package br.edu.ufca.banco;

import java.util.ArrayList;

public class RepositorioConta {
	
	private ArrayList<ContaAbstrata> contas;
	
	public RepositorioConta() {
		this.contas = new ArrayList<ContaAbstrata>();
	}
	
	public void adicionaConta(ContaAbstrata c) {
		
	}
	
	public int consultaConta(ContaAbstrata c) {
		return -1;
	}
	
	public void removeConta(ContaAbstrata c) {
		
	}

}
